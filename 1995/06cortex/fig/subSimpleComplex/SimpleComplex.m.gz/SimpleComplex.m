
cd /home/brian/book/05cortex/fig/subSimpleComplex

load simpleComplex 

plotParms(plot(simpleT,simpleR))
grid on
print -deps simple.eps

plotParms(plot(complexT,complexR))
grid on
print -deps complex.eps

