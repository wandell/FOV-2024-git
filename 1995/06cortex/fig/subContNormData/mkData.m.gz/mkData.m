%
%	Preliminary...shouldn't need to do again
%
load albrechtRawData

logContrast = contNormDataInches(:,1)/3;
logSpikes =  (7 - contNormDataInches(:,[2:5]))/3;

save albrechtData logContrast logSpikes

