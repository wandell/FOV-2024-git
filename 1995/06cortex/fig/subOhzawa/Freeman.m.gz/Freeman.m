%
%	Convert the scanned F+O pseudocolor into
%	a gray scale.
%
cd /wusr5/brian/book/05cortex/fig/subFreeman

[fo1 m1] = rsread('FreemanOhzawa.ras');
image(fo1); colormap(m1);
s1 = size(fo1);

[fo2 m2] = rsread('FreemanOhzawa2.ras');
image(fo2); colormap(m2);
s2 = size(fo2);

%
%	Convert first image
%

%	 Map the color map to gray scale
%
grayLevels = m1*[1 -1 0]';
grayLevels= (grayLevels - min(grayLevels)) / ...
		(max(grayLevels) - min(grayLevels));
grayMap = [grayLevels, grayLevels, grayLevels];
image(fo1)
colormap(grayMap)

%
%	Convert the image data themselves.  Not necessary
%	but it helps with IslandDraw
%
colormap(gray(64))
fo1Gray = reshape(grayLevels(fo1),s1(1),s1(2));
imagesc(fo1Gray)
axis image
axis off
rswrite('fo1.ras',fo1Gray,gray(64));

%
%	Convert the second image
%

grayLevels = m2*[1 -1 0]';
grayLevels= (grayLevels - min(grayLevels)) / ...
		(max(grayLevels) - min(grayLevels));
grayMap = [grayLevels, grayLevels, grayLevels];
image(fo2)
colormap(grayMap)

colormap(gray(64))
fo2Gray = reshape(grayLevels(fo2),s2(1),s2(2));
imagesc(fo2Gray)
axis image
axis off

rswrite('fo2.ras',fo2Gray,gray(64));

%
%	Then, I used xv to clip out the images.
%	I probably should have just clipped them in matlab
%	for equal size before writing them out.
%
