
cd /wusr5/brian/book/05cortex/fig/subBinoc

load poggioTalbot

plotParms(plot(tf(:,1),tf(:,2),'w-',tf(:,1),tf(:,2),'wo'))
grid on
set(gca,'xtick',[-1:.5:1],'ytick',[0:10:50], ...
    'ylim', [0 max(tf(:,2)*1.2) ],'xlim',[-1 1] )
print -deps tf.eps

plotParms(plot(tn(:,1),tn(:,2),'w-',tn(:,1),tn(:,2),'wo'))
grid on
set(gca,'xtick',[-1:.5:1],'ytick',[0:10:50], ...
    'ylim', [0 max(tn(:,2)*1.2) ],'xlim',[-1 1] )
print -deps tn.eps

plotParms(plot(ti(:,1),ti(:,2),'w-',ti(:,1),ti(:,2),'wo'))
grid on
set(gca,'xtick',[-1:.5:1],'ytick',[0:10:80], ...
    'ylim', [0 max(ti(:,2)*1.2) ],'xlim',[-1 1] )
print -deps ti.eps

plotParms(plot(te(:,1),te(:,2),'w-',te(:,1),te(:,2),'wo'))
grid on
set(gca,'xtick',[-1:.5:1],'ytick',[0:10:50], ...
    'ylim', [0 max(te(:,2)*1.2) ],'xlim',[-1 1] )
print -deps te.eps


