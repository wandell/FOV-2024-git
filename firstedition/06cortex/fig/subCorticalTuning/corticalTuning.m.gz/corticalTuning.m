%
%	DeValois cortical tuning data
%
cd /home/brian/book/05cortex/fig/subCorticalTuning

load corticalTuning

%
%	To check, do this
%
p = plot(sf,response, 'wo',sf,response,'w-')
plotParms(p)
set(gca,'xscale','log','yscale','log')
set(gca,'xlim',[.3 50],'ylim',[10 2000])
set(gca,'xtick',[.3 1 3 10 30],'ytick',[10 30 100 300 1000 3000])

grid on

print -deps corticalTuning.eps

