%
%	Data from Albrecht and Hamilton, 1982.
%

cd /home/brian/book/05cortex/fig/subContNormData

load albrechtData
%
%	Log contrast versus log response
%
logContrast
p = plot(logContrast,logSpikes(:,1),'o',...
	logContrast,logSpikes(:,2),'o',...
	logContrast,logSpikes(:,3),'o',...
	logContrast,logSpikes(:,4),'o',...
	logContrast,logSpikes(:,1),...
	logContrast,logSpikes(:,2),...
	logContrast,logSpikes(:,3),...
	logContrast,logSpikes(:,4))
plotParms(p)
set(gca,'xtick',[0 0.5 1 1.5 2],'ytick',[0 0.5 1 1.5 2])
grid on
print -dps contNormData.ps

%
%	Make a graph of the spatial frequency tuning
%
%	Not used at present
%
c = .9:.1:1.6;		%contrast range for interpolation

%	This is the ordering of the data originally
%		sf = [0.5 2 1.5 1];

sf = [0.5 1 1.5 2];
r1 = interp1(logContrast,logSpikes(:,1), c)
r2 = interp1(logContrast,logSpikes(:,2), c)
r3 = interp1(logContrast,logSpikes(:,3), c)
r4 = interp1(logContrast,logSpikes(:,4), c)
r = [r1,r4, r3,r2]'

p = plot(sf,r(:,1),'o', ...
     sf,r(:,8),'o', ...
     sf,r(:,1),'w-',...
     sf,r(:,8),'w-'     )
plotParms(p)
set(gca,'xtick',[0 0.5 1 1.5 2],'ytick',[0 0.5 1 1.5 2])
grid on
print -deps contTuning.eps

%
%	Original linear panel plot
%
contrast = 10 .^ logContrast;
contrast = [0 ; contrast];
spikes = 10 .^ logSpikes;
spikes = [0 0 0 0; spikes];
for i= 1:4
  subplot(2,2,i)
  plot(contrast,spikes(:,i),'x',...
       contrast,spikes(:,i),'-');
  set(gca,'ylim',[0 60]);
end
print -deps contNormaDataPanel.eps

plot(contrast,spikes(:,i),'x', ...
     contrast,spikes(:,1),'-', ...
     contrast,spikes(:,2),'o', ...
     contrast,spikes(:,2),'-', ...
     contrast,spikes(:,3),'*', ...
     contrast,spikes(:,3),'-', ...
     contrast,spikes(:,4),'*', ...
     contrast,spikes(:,4),'-');

set(gca,'Xscale','log','Yscale','log');
print -deps contNormaData.eps

%xlabel('Percent Contrast');
%ylabel('spikes per second');
